﻿using System;

namespace Car_application
{
    class Program
    {

        static int indx = 0;

        static Car[] Catelog = new Car[30];

        static void Main(string[] arg)
        {

            string command = string.Empty;

            while (command != "5")
            {

                Console.WriteLine("Enter the number : what you want to do ");

                Console.WriteLine("1. Add ");

                Console.WriteLine("2. Display ");

                Console.WriteLine("3. Edit ");

                Console.WriteLine("4. Delete ");

                Console.WriteLine("5. Search ");

                command = Console.ReadLine();

                switch (command)
                {

                    case "1":
                        {

                            Console.Write("Date ");

                            string date = Console.ReadLine();

                            Console.Write("Mark: ");

                            string mark = Console.ReadLine();

                            Console.Write("Model: ");

                            string model = Console.ReadLine();

                            Console.Write("Plate ");

                            string plate = Console.ReadLine();

                            Console.Write("colour ");

                            string colour = Console.ReadLine();

                            Console.Write("engine power ");

                            string enginepower = Console.ReadLine();

                            Add (date, mark, model, plate ,colour, enginepower);

                            break;

                        }

                    case "2":
                        {

                            Display();

                            break;

                        }

                    case "3":
                        {

                            Edit();

                            break;

                        }
                    case "4":
                        {

                            Delete();

                            break;

                        }
                    case "5":
                        {
                            Console.Write("Date Mark Model Plate Colour Enginepower ");

                            string mark = Console.ReadLine();
                            string date = Console.ReadLine();
                            string model = Console.ReadLine();
                            string plate = Console.ReadLine();
                            string colour = Console.ReadLine();
                            string enginepower = Console.ReadLine();

                            Search(date);
                            Search(mark);
                            Search(model);
                            Search(plate);
                            Search(colour);
                            Search(enginepower);

                            break;

                        }

                    



                }

            }

        }

        private static void Search(string date)
        {
            for (int i = 0; i <= Catelog.Length - 1; i++)
            {
                if (Catelog[i].date == date)
                {
                    Console.Write("{0}\t", Catelog[i].Date);

                    Console.Write("{0}\t", Catelog[i].Mark);

                    Console.Write("{0}\t", Catelog[i].Model);

                    Console.Write("{0}", Catelog[i].Plate);

                    Console.Write("{0}\t", Catelog[i].Colour);

                    Console.Write("{0}\t", Catelog[i].Enginepower);


                    Console.WriteLine("");
                    break;
                }
            }

        }

        public static void DisplayByDate()
        {
            Array.Sort(Catelog, (ICompare)new Car.SortByDateClass());

            Console.WriteLine("Date    Mark   Model   Plate  Colour   Enginepower");

            Console.WriteLine("=======================================================");

            for (int i = 0; i <= Catelog.Length - 1; i++)
            {

                if (Catelog[i] != null)
                {
                    Console.Write("{0}\t", Catelog[i].Date);

                    Console.Write("{0}\t", Catelog[i].Mark);

                    Console.Write("{0}\t", Catelog[i].Model);

                    Console.Write("{0}", Catelog[i].Plate);

                    Console.Write("{0}", Catelog[i].Colour);

                    Console.Write("{0}", Catelog[i].Enginepower);

                    Console.WriteLine("");

                }
            }
        }



        public static void Add(string date, string mark, string model, string plate, string colour, string enginepower)
        {

            Catelog[indx] = new Car(date, mark, model, plate, colour, enginepower);

            indx++;

        }



        public static void Display()
        {
            Console.WriteLine("Date    Mark   Model   Plate Colour Enginepower");

            Console.WriteLine(".........");

            for (int i = 0; i <= Catelog.Length - 1; i++)
                if (Catelog[i] != null)
                {
                    Console.Write("{0}\t", Catelog[i].Date);

                    Console.Write("{0}\t", Catelog[i].Mark);

                    Console.Write("{0}\t", Catelog[i].Model);

                    Console.Write("{0}", Catelog[i].Plate);

                    Console.Write("{0}", Catelog[i].Colour);

                    Console.Write("{0}", Catelog[i].Enginepower);

                    Console.WriteLine("");
                }
        }

    }

    

public class Car : ICompare
{
    public string sortby;

    private string _mark;

    private string _model;

    private double _plate;

    private string _date;

    private string _colour;

    private string _enginepower;



        public Car(string date, string mark, string model, string plate, string colour, string enginepower)
    {

        Date = date;

        Mark = mark;

        Model = model;

        Plate = plate;

         Colour = colour;

        Enginepower = enginepower;



    }

    public string Mark
    {

        get
        {

            return _mark;

        }

        set
        {

            _mark = value;

        }

    }
        public string Model
        {

            get
            {

                return _model;

            }

            set
            {

                _model = value;

            }

        }
        public string Colour
        {

            get
            {

                return _colour;

            }

            set
            {

                _colour = value;

            }

        }

        public string Enginepower
    {

        get
        {

            return _enginepower;

        }

        set
        {

            _enginepower = value;

        }

    }

    public string Plate
    {

        get
        {

            return _plate;

        }

        set
        {

            _plate = value;

        }

    }

    public string Date
    {

        get
        {

            return _date;

        }

        set
        {

            _date = value;

        }

    }

    

    
    }

}


