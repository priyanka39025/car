﻿using System;
using System.Collections.Generic;

namespace Car_application
{
    class Program
    {

        static int indx = 0;

        static List<Car> carLog = new List<Car>(); //<> generic typecast bolte hain . kisi bhi type ke type store kar sakte hai chahe class ho ,int string map hash ho

        static void Main(string[] arg)
        {
           

            string command = string.Empty;

            while (command != "6")
            {

                Console.WriteLine("Enter the number : what you want to do ");

                Console.WriteLine("1. Add ");

                Console.WriteLine("2. Display ");

                Console.WriteLine("3. Edit ");

                Console.WriteLine("4. Delete ");

                Console.WriteLine("5. Search ");

                Console.WriteLine("6. Exit ");

                command = Console.ReadLine();

                switch (command)
                {

                    case "1":
                        {
                            //carLog.Add(new Car("15 may", "audi", "Q7", "0786", "RED", "700cc")); // e bject hai audi se related
                            //carLog.Add(new Car("16 may", "Maruti", "800", "0777", "  BLUE", "500cc")); // ye maruti se
                            //carLog.Add(new Car("17 may", "Safari", "A9", "8769", "WHITE", "300cc"));
                            //carLog.Add(new Car("18 may", "BMW", "SUV", "111", "PINK", "600cc"));
                            //carLog.Add(new Car("19 may", "FARARI", "WWW", "23MV6", "YELLOW", "500cc"));

                            Console.Write("Date ");

                            string date = Console.ReadLine();

                            Console.Write("Mark: ");

                            string mark = Console.ReadLine();

                            Console.Write("Model: ");

                            string model = Console.ReadLine();

                            Console.Write("Plate ");

                            string plate = Console.ReadLine();

                            Console.Write("colour ");

                            string colour = Console.ReadLine();

                            Console.Write("engine power ");

                            string enginepower = Console.ReadLine();

                            Add(date, mark, model, plate, colour, enginepower);

                            break;

                        }

                    case "2":
                        {

                            Display();

                            break;

                        }

                    case "3":
                        {
                            Console.WriteLine("Which one you want to edit ?");

                            String pos = Console.ReadLine();

                            Edit(Int32.Parse(pos));

                            break;

                        }
                    case "4":
                        {
                            Console.WriteLine("Do you want to delete which Mark ?");

                            String pos = Console.ReadLine();

                            Delete(Int32.Parse(pos));

                            break;

                        }
                    case "5":
                        {
                            Console.Write("What do you want to search ?");

                            string str = Console.ReadLine();
                     

                            Search(str);
                          

                            break;

                        }


                }

            }

        }

        private static void Search(string str)
        {
            for (int i = 0; i <= carLog.Count - 1; i++)
            {
                if (carLog[i].Date.ToLower() == str.ToLower() || carLog[i].Mark.ToLower() == str.ToLower() || carLog[i].Model.ToLower() == str.ToLower() || carLog[i].Plate.ToLower() == str.ToLower())
                {
                    Console.Write("{0}\t", carLog[i].Date);

                    Console.Write("{0}\t", carLog[i].Mark);

                    Console.Write("{0}\t", carLog[i].Model);

                    Console.Write("{0}\t", carLog[i].Plate);

                    Console.Write("{0}\t", carLog[i].Colour);

                    Console.Write("{0}\t", carLog[i].Enginepower);


                    Console.WriteLine("");
                    break;
                }
            }

        }

        public static void DisplayByDate()
        {
           // Array.Sort(new Car.SortByDateClass());

            Console.WriteLine("Date    Mark   Model   Plate  Colour   Enginepower");

            Console.WriteLine("=======================================================");

            for (int i = 0; i <= carLog.Count - 1; i++)
            {

                if (carLog[i] != null)
                {
                    Console.Write("{0}\t", carLog[i].Date);

                    Console.Write("{0}\t", carLog[i].Mark);

                    Console.Write("{0}\t", carLog[i].Model);

                    Console.Write("{0}", carLog[i].Plate);

                    Console.Write("{0}", carLog[i].Colour);

                    Console.Write("{0}", carLog[i].Enginepower);

                    Console.WriteLine("");

                }
            }
        }



        public static void Add(string date, string mark, string model, string plate, string colour, string enginepower)
        {

            carLog.Add( new Car(date, mark, model, plate, colour, enginepower));

        }



        public static void Display()
        {
            Console.WriteLine("Id      Date    Mark   Model   Plate Colour Enginepower");

            Console.WriteLine(".........");

            for (int i = 0; i <= carLog.Count - 1; i++)
                if (carLog[i] != null)
                {
                    Console.Write("{0}\t", i);

                    Console.Write("{0}\t", carLog[i].Date);

                    Console.Write("{0}\t", carLog[i].Mark);

                    Console.Write("{0}\t", carLog[i].Model);

                    Console.Write("{0}\t", carLog[i].Plate);

                    Console.Write("{0}\t", carLog[i].Colour);

                    Console.Write("{0}\t", carLog[i].Enginepower);

                    Console.WriteLine("");
                }
        }

        public static void Delete(int pos)
        {
            Console.WriteLine("Date    Mark   Model   Plate Colour Enginepower");
            Console.WriteLine(carLog[pos].Mark + "is Deleted");
            Console.WriteLine(".........");

            carLog.RemoveAt(pos);
        }

        public static void Edit(int pos)
        {

            Console.Write("Date ");

            string date = Console.ReadLine();

            Console.Write("Mark: ");

            string mark = Console.ReadLine();

            Console.Write("Model: ");

            string model = Console.ReadLine();

            Console.Write("Plate ");

            string plate = Console.ReadLine();

            Console.Write("colour ");

            string colour = Console.ReadLine();

            Console.Write("engine power ");

            string enginepower = Console.ReadLine();

            Console.WriteLine(".........");

     
            Car updateCar = carLog[pos]; // <--- Object le rahe . lst banayi car class ki to usme car ke object store ye hain
            updateCar.Mark = mark == "" ? carLog[pos].Mark : mark; // pehle  chek karega k console mei mark ko kuch value di haiagar nahi carLog[pos].Mark iski value lega otherwise mark ki
            updateCar.Model = model == "" ? carLog[pos].Model : model;
            updateCar.Plate = plate == "" ? carLog[pos].Plate : plate;
            updateCar.Colour = colour == "" ? carLog[pos].Colour : colour;
            updateCar.Date = date == "" ? carLog[pos].Date : date;

            Console.WriteLine(carLog[pos].Mark +" is Updated");
        }
    }

    

public class Car // mddel class
{
    

    private string _mark;

    private string _model;

    private string _plate;

    private string _date;

    private string _colour;

    private string _enginepower;



        public Car(string date, string mark, string model, string plate, string colour, string enginepower)
    {

        Date = date;

        Mark = mark;

        Model = model;

        Plate = plate;

        Colour = colour;

        Enginepower = enginepower;

    }

    public string Mark
    {

        get
        {

            return _mark;

        }

        set
        {

            _mark = value;

        }

    }
        public string Model
        {

            get
            {

                return _model;

            }

            set
            {

                _model = value;

            }

        }
        public string Colour
        {

            get
            {

                return _colour;

            }

            set
            {

                _colour = value;

            }

        }

        public string Enginepower
    {

        get
        {

            return _enginepower;

        }

        set
        {

            _enginepower = value;

        }

    }

    public String Plate
    {

        get
        {

            return _plate;

        }

        set
        {

            _plate = value;

        }

    }

    public string Date
    {

        get
        {

            return _date;

        }

        set
        {

            _date = value;

        }

    }

    

    
    }

}


